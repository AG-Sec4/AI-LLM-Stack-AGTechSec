#!/bin/bash
docker restart ollama openwebui invokeai
