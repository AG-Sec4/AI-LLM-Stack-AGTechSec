#!/bin/bash
docker ps
nvidia-smi
sudo systemctl status nginx
